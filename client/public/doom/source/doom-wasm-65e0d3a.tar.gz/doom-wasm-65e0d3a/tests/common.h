#define A = 1
